﻿namespace DLHApi.Common.Models
{
    public interface IDlhApiResponse
    {
    }
}
