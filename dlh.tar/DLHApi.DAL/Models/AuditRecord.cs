﻿namespace DLHApi.DAL.Models
{
    public class AuditRecord
    {
        public Guid Id { get; set; }
    }
}
