﻿namespace DLHApi.DAL.Models
{
    public class DlhHistoryDisplay
    {
        public string? IssueDate { get; set; }
        public string? ServiceType { get; set; }
        public string? LicClass { get; set; }
    }
}
