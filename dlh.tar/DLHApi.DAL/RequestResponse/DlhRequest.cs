﻿namespace DLHApi.DAL.RequestResponse
{
    public class DlhRequest
    {
        public int Mvid { get; set; }
    }
}
