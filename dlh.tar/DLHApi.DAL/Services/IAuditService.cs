﻿namespace DLHApi.DAL.Services
{
    public interface IAuditService
    {
        void AddRequestAudit(string mvid);
    }
}
