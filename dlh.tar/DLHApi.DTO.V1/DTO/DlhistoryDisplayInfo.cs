﻿namespace DLHApi.DTO.V1.DTO
{
    public class DlhistoryDisplayInfo
	{
        public string? IssueDate { get; set; }
        public string? ServiceType { get; set; }
        public string? LicClass { get; set; }
    }
}
