﻿namespace DLHApi.EIS.Models
{
	public class DmsRequest
    {
        public string? Template { get; set; }
        public string? jsonDataSet { get; set; }
    }
}

