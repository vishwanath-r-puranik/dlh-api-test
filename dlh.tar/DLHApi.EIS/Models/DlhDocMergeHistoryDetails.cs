﻿namespace DLHApi.EIS.Models
{
	public class DlhDocMergeHistoryDetails
	{
        public string? DlhServiceType { get; set; }

        public string? DlhIssueDate { get; set; }

        public string? DlhClass { get; set; }
    }
}

