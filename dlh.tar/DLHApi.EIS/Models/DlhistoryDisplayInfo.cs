﻿namespace DLHApi.EIS.Models
{
    public class DlhistoryDisplayInfo
	{
        public string? IssueDate { get; set; }
        public string? ServiceType { get; set; }
        public string? LicenseClass { get; set; }
    }
}